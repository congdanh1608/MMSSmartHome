#!/bin/bash

java -jar RaspServer.jar