#!/bin/bash
DB_ROOT_USER='root'
DB_ROOT_PASS='123456'
  
EXPECTED_ARGS=3
E_BADARGS=65
MYSQL=`which mysql`
  
Q1="DROP homemmsdb"
SQL="${Q1}"
  
$MYSQL -u "$DB_ROOT_USER" --password="$DB_ROOT_PASS" -e "$SQL"
sudo cp bak/interfaces /etc/network/ && sudo cp bak/wpa_supplicant.conf /etc/wpa_supplicant/ && sudo cp bak/rc.local /etc/rc.local && sudo rm -rf bak deb shell start wifi_config wifi_router configrasppi.zip RaspServer.jar && sudo rm -rf .config/autostart && sudo reboot && echo EndCommands
