#!/bin/bash

if [ $1 = "normal" ]
then
	sudo yes | sudo cp -rf /home/pi/bak/interfaces /etc/network/ && sudo rm -rf /etc/hostapd/hostapd.conf && sudo rm -rf /etc/default/hostapd && sudo rm -rf /etc/dhcp/dhcpd.conf && sudo rm -rf /usr/sbin/hostapd && sudo dpkg -P isc-dhcp-server libnl-route && sudo reboot
	echo EndCommands
fi
if [ $1 = "ad-hoc" ]
then
	sudo dpkg -i /home/pi/deb/dep_router/*.deb && sudo cp /home/pi/wifi_router/interfaces /etc/network/ && sudo cp /home/pi/wifi_router/hostapd.conf /etc/hostapd/ && sudo cp  /home/pi/wifi_router/hostapd /etc/default/ && sudo cp /home/pi/wifi_router/dhcpd.conf /etc/dhcp/ && sudo reboot
	echo EndCommands
fi