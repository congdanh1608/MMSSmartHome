#!/bin/bash
  
sudo dpkg -i /home/pi/deb/dep_router/*.deb && sudo cp /home/pi/wifi_router/interfaces /etc/network/ && sudo cp /home/pi/wifi_router/hostapd.conf /etc/hostapd/ && sudo cp  /home/pi/wifi_router/hostapd /etc/default/ && sudo cp /home/pi/wifi_router/dhcpd.conf /etc/dhcp/ && sudo reboot
echo EndCommands