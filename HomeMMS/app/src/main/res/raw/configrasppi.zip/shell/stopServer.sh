#!/bin/bash

pid=`ps aux | grep java | awk '{print $2}'`
kill -9 $pid